classdef Alignment
    methods (Abstract)
        aligned_shapes = align(obj, data)
    end
end